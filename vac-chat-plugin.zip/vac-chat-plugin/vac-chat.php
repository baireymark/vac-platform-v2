<?php
/**
 * Plugin Name: Gunny — VAC Chatbot
 * Description: Adds the Gunny chat widget to every page. Optional AI fallback via /wp-json/vac/v1/chat.
 * Version: 1.0.0
 *
 * Install: upload this folder (with vac-chatbot.js inside it) to wp-content/plugins/ and activate.
 * AI fallback (optional): add to wp-config.php →  define('VAC_ANTHROPIC_KEY', 'sk-ant-...');
 * Lead webhook (optional): add to wp-config.php → define('VAC_LEAD_WEBHOOK', 'https://hooks.zapier.com/...');
 */
if (!defined('ABSPATH')) exit;

/* 1) Load the widget on every page ------------------------------------- */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('vac-chatbot', plugins_url('vac-chatbot.js', __FILE__), [], '1.0.0', true);
    $config = [
        'leadWebhook' => defined('VAC_LEAD_WEBHOOK') ? VAC_LEAD_WEBHOOK : '',
        'aiEndpoint'  => defined('VAC_ANTHROPIC_KEY') ? esc_url_raw(rest_url('vac/v1/chat')) : '',
    ];
    wp_add_inline_script('vac-chatbot', 'window.VACChatConfig=' . wp_json_encode($config) . ';', 'before');
});

/* 2) Optional AI endpoint — keeps the API key on the server ------------- */
add_action('rest_api_init', function () {
    register_rest_route('vac/v1', '/chat', [
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => 'vac_chat_handle',
    ]);
});

function vac_chat_system_prompt() {
    return <<<TXT
You are "Gunny", the website chat assistant for Veterans Advocate Center (VAC), https://veteransadvocatecenter.com.
Answer briefly (2–5 sentences), warmly, in plain language. Only use the facts below; if you don't know, say so and refer the visitor to an advocate.

FACTS
- VAC is a veteran-owned and operated organization that simplifies the VA benefits process, for veterans who were denied before or never applied. Motto: "Turning disabilities into possibilities."
- Services: (1) Benefits Eligibility Assessment – reviews service history and circumstances to find benefits the veteran may have earned; (2) Application Assistance – helps make applications complete and accurate; (3) Appeal Support – reviews and helps pursue denied claims.
- Process: Eligibility check → Personalized plan with an assigned veteran advocate → Work toward results.
- Benefits veterans may qualify for: healthcare, disability compensation, education assistance, home loans, pension, vocational training, survivor support.
- Timeline: typically months; appeals can take a year or longer.
- After a denial: read the denial letter, gather new/missing evidence that addresses the reasons, respond within deadlines; options can include the Board of Veterans' Appeals or a supplemental claim with new evidence.
- Common mistakes: missing evidence (medical/service records), missed deadlines, not knowing all available benefits, delaying because the condition seems "not bad enough".
- The initial evaluation is free. For fee questions, refer to an advocate.
- Contact: +1 877-822-2023, info@vac2023.com. Free evaluation form: https://veteransadvocatecenter.com/#form. Rating calculator: https://veteransadvocatecenter.com/#calculator.
- Disclaimer: VAC is NOT a law firm, attorney, or VA-accredited claims agent and does NOT represent veterans before the VA or BVA. Free help exists through accredited Veterans Service Organizations and VA.gov.

RULES
- Never give legal advice, predict a specific rating or dollar amount, or promise outcomes.
- Don't discuss topics unrelated to veterans' benefits or VAC; politely redirect.
- If someone mentions suicide, self-harm, or crisis: give the Veterans Crisis Line first — call 988 then press 1, text 838255, or chat at VeteransCrisisLine.net; 911 for emergencies.
- Do not ask for SSNs, VA file numbers, or medical details in chat.
TXT;
}

function vac_chat_handle(WP_REST_Request $req) {
    if (!defined('VAC_ANTHROPIC_KEY')) return new WP_REST_Response(['reply' => ''], 503);

    // Basic per-IP rate limit: 30 requests / 10 minutes
    $ip  = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'x');
    $key = 'vac_rl_' . md5($ip);
    $n   = (int) get_transient($key);
    if ($n >= 30) return new WP_REST_Response(['reply' => 'You\'ve sent a lot of messages. Please call +1 877-822-2023 to talk with an advocate.'], 200);
    set_transient($key, $n + 1, 10 * MINUTE_IN_SECONDS);

    $messages = [];
    foreach ((array) $req->get_param('messages') as $m) {
        $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $text = mb_substr(wp_strip_all_tags((string) ($m['content'] ?? '')), 0, 1500);
        if ($text === '') continue;
        // Merge consecutive same-role turns (API requires alternation)
        if ($messages && end($messages)['role'] === $role) {
            $messages[count($messages) - 1]['content'] .= "\n" . $text;
        } else {
            $messages[] = ['role' => $role, 'content' => $text];
        }
    }
    $messages = array_slice($messages, -12);
    while ($messages && $messages[0]['role'] !== 'user') array_shift($messages);
    if (!$messages) return new WP_REST_Response(['reply' => ''], 400);

    $res = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'timeout' => 30,
        'headers' => [
            'x-api-key'         => VAC_ANTHROPIC_KEY,
            'anthropic-version' => '2023-06-01',
            'content-type'      => 'application/json',
        ],
        'body' => wp_json_encode([
            'model'      => defined('VAC_MODEL') ? VAC_MODEL : 'claude-haiku-4-5-20251001',
            'max_tokens' => 400,
            'system'     => vac_chat_system_prompt(),
            'messages'   => $messages,
        ]),
    ]);
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) {
        return new WP_REST_Response(['reply' => ''], 502);
    }
    $body  = json_decode(wp_remote_retrieve_body($res), true);
    $reply = '';
    foreach (($body['content'] ?? []) as $block) {
        if (($block['type'] ?? '') === 'text') $reply .= $block['text'];
    }
    return new WP_REST_Response(['reply' => trim($reply)], 200);
}
