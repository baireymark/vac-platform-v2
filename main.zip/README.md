# VAC V4 "Field Briefing" (HTML)

A static HTML/CSS/JS build of the **VAC V4** homepage from the Figma file (Finalized Studies → `VAC V4`, plus `VAC V4 / Mobile / 390` for small screens). There is no build step. The only dependency is `nodemailer`, which the server uses for form email.

## Run it

```bash
npm install
npm start
```

Then open http://localhost:4174. For form email, see [Email (SMTP)](#email-smtp). Serve it over http rather than opening `index.html` as a file: the calculator reads pixel data from the model frames, which browsers block on `file://`.

## What's interactive

- **2.5D calculator.** The model turns through 13 body frames, by dragging, the ‹ › buttons or the arrow keys.
  - Clicking a body part (head, torso, either arm, either leg), or choosing it from the list, highlights that part's whole outline in red. There are no dot markers.
  - Head, ear and forehead conditions (mental health, hearing, migraine, sleep) switch to the 14-frame head turntable and highlight that area.
  - Effect, severity (10 steps), "Add condition", the list of added conditions and the household controls all work.
  - The estimate tag shows **example values only**; there is no rating maths yet.
- **Free evaluation intake.** The three steps from veteransadvocatecenter.com, with validation, Back, and a confirmation screen.
- **Contact form.** Name, email, phone, message and the SMS consent text copied word for word, with validation.
- **Other.** Mobile menu (Escape closes it), FAQ answers revealed on tap, and story videos that play in a dialog from the live site's video URLs.

## Email (SMTP)

Both forms and the chatbot's lead flows are emailed through SMTP by `serve.mjs`:

| Endpoint | Sent by |
| --- | --- |
| `POST /api/intake` | Free evaluation intake (`app.js`) |
| `POST /api/contact` | Contact form (`app.js`) |
| `POST /api/lead` | Chatbot callback / eligibility flows (`leadWebhook` in `index.html`) |

To set it up, copy `.env.example` to `.env` and fill in `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` and `MAIL_TO`. Then run `npm install` and `npm start`. On startup the server logs `SMTP ready` or the reason the connection check failed.

- Emails go to `MAIL_TO`, with **Reply-To** set to the visitor, so replying in your inbox answers them directly.
- The server checks fields again before sending, limits each IP to 10 submissions per 10 minutes, and has a hidden honeypot field for bots.
- If SMTP isn't configured or a send fails, the forms show an error with the phone number. The chatbot falls back to its pre-filled `mailto:` link.
- `.env`, dotfiles, `node_modules` and the server files are never served.
- After a successful send the forms still fire `vac:intake` / `vac:contact` events for analytics.

### On Vercel

Vercel doesn't run `serve.mjs`. It serves the static files and runs `api/[form].js` as a serverless function for the same three endpoints. Both use the shared code in `api/_mail.js`. There's no `.env` on Vercel: add the same `SMTP_*` and `MAIL_*` variables under **Project → Settings → Environment Variables**, then redeploy.

## How part selection works

`turntable.js` reads each frame's alpha mask and splits the silhouette at runtime:

- **Neck:** the narrowest row near the top.
- **Crotch:** where a gap opens between the legs.
- **Arms:** found where they separate from the torso. In side views, where the arms overlap the body, a band from the shoulder is used instead.

The highlight is then clipped to the exact silhouette. `vacCalculator.segmentationOf(i)` returns the label map for frame `i`, for tuning.

## Assets

- `assets/turntable/`: frames from the 2.5D viewer prototype (`Downloads/vac_2_5d_viewer`), re-encoded to WebP (about 4 MB instead of about 48 MB). Body frames are normalised to the same height, floor line and centre axis so the model doesn't jump between angles.
- `assets/img`, `assets/svg`: exported from the V4 Figma frames. The hero background is the flattened flag layer.
- `assets/svg/topo-wide.svg`: the V4 topo regenerated 3840 wide, with the design column in the middle and extra contours on each side, so it reaches the screen edges without stretching.

## Full-width behaviour (desktop)

Content stays in the 1280 design column. These elements run the full width of the screen:

- **Hero:** exactly one screen tall. It scales to fit, and any spare height centres the copy and enlarges the portrait. The stats bar runs edge to edge.
- **Film strip:** runs past both screen edges. `app.js` fills it with decorative copies of the stills, which are hidden from screen readers and the Tab key.
- **Ball chain:** drawn by `app.js` across the screen width, with each dog tag lowered to meet it.
- **Topo map:** the wide SVG above.
- Photo rights, the story videos and the hero stats ("100%", "1,000+") still need sign-off. See the V4 review notes in Figma.
