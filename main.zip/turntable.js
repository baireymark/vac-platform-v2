/* VAC V4 calculator: 2.5D turntable + body-part selection.
   Frames come from the VAC 2.5D viewer prototype (normalised to 800x1424 WebP: same height, same floor, neck on
   the centre axis). Parts are segmented at runtime from each frame's alpha channel, so the highlight follows the
   real silhouette instead of a dot. Needs http(s): canvas pixel reads are blocked on file://. */
(() => {
  "use strict";

  const root = document.getElementById("tt");
  if (!root) return;

  const BODY = [
    [0, "000-front"], [22.5, "023-front-right"], [45, "045-front-right"], [67.5, "068-near-right"],
    [90, "090-right"], [112.5, "113-right-rear"], [135, "135-right-rear"], [180, "180-back"],
    [225, "225-back-left"], [247.5, "248-near-left"], [270, "270-left"], [315, "315-front-left"], [337.5, "338-near-front-left"],
  ].map(([a, f]) => ({ a, src: `assets/turntable/body/${f}.webp` }));
  const HEAD = [
    [0, "000-front"], [22.5, "023-front-right"], [45, "045-front-right"], [67.5, "068-near-right"], [90, "090-right"],
    [112.5, "113-right-rear"], [157.5, "158-near-back-right"], [180, "180-back"], [202.5, "203-near-back-left"],
    [247.5, "248-left-rear"], [270, "270-left"], [292.5, "293-near-left"], [315, "315-front-left"], [337.5, "338-near-front-left"],
  ].map(([a, f]) => ({ a, src: `assets/turntable/head/${f}.webp` }));

  // Label ids written into the segmentation map.
  const L = { none: 0, head: 1, torso: 2, rightArm: 3, leftArm: 4, rightLeg: 5, leftLeg: 6, legs: 7 };
  const PART_NAMES = { head: "Head", torso: "Torso", rightArm: "Right arm", leftArm: "Left arm", rightLeg: "Right leg", leftLeg: "Left leg" };
  const COND_NAMES = { mentalHealth: "Mental health", hearing: "Hearing", migraine: "Migraine", sleep: "Sleep", other: "Other" };
  const HEAD_CONDS = new Set(["mentalHealth", "hearing", "migraine", "sleep"]);
  const SEV_TEXT = v => (v <= 3 ? "A little" : v <= 6 ? "Some" : v <= 8 ? "A lot" : "Severe");

  const el = {
    img: document.getElementById("ttImg"),
    paint: document.getElementById("ttPaint"),
    tag: root.querySelector(".tt__tag"),
    tagLabel: document.getElementById("ttTagLabel"),
    view: document.getElementById("ttView"),
    angle: document.getElementById("ttAngle"),
    meter: document.getElementById("sevMeter"),
    sevText: document.getElementById("sevText"),
    add: document.getElementById("addCond"),
    list: document.getElementById("condsList"),
    title: document.getElementById("condsTitle"),
    empty: document.getElementById("condsEmpty"),
    live: document.getElementById("calcLive"),
  };
  const pctx = el.paint.getContext("2d");

  const state = {
    mode: "body",
    angle: 0,
    active: { type: "part", id: "leftLeg" },
    hover: null,
    effect: "Limited motion",
    severity: 7,
    conds: [],
    drag: null,
  };

  // ---------------------------------------------------------------- frames + segmentation
  const cache = new Map(); // src -> { img, seg }
  const SW = 400; // analysis width (half of the 800px frames)

  const norm = a => ((a % 360) + 360) % 360;
  const dist = (a, b) => Math.abs(((a - b + 540) % 360) - 180);
  const frames = () => (state.mode === "body" ? BODY : HEAD);
  const nearest = (list, a) => list.reduce((best, f) => (dist(f.a, a) < dist(best.a, a) ? f : best), list[0]);

  function loadFrame(src) {
    let entry = cache.get(src);
    if (entry) return entry.ready;
    const img = new Image();
    img.decoding = "async";
    entry = { img, seg: null };
    entry.ready = new Promise(resolve => {
      img.onload = () => resolve(entry);
      img.onerror = () => resolve(entry);
    });
    img.src = src;
    cache.set(src, entry);
    return entry.ready;
  }

  function readAlpha(img) {
    const SH = Math.round(SW * img.naturalHeight / img.naturalWidth);
    const c = document.createElement("canvas");
    c.width = SW; c.height = SH;
    const x = c.getContext("2d", { willReadFrequently: true });
    x.drawImage(img, 0, 0, SW, SH);
    const d = x.getImageData(0, 0, SW, SH).data; // throws on file://
    const on = new Uint8Array(SW * SH);
    for (let i = 0; i < on.length; i++) on[i] = d[i * 4 + 3] > 100 ? 1 : 0;
    const runs = new Array(SH);
    let top = -1, bot = -1;
    for (let y = 0; y < SH; y++) {
      const r = [];
      let s = -1;
      for (let xx = 0; xx <= SW; xx++) {
        const v = xx < SW && on[y * SW + xx];
        if (v && s < 0) s = xx;
        else if (!v && s >= 0) { if (xx - s >= 2) r.push([s, xx - 1]); s = -1; }
      }
      runs[y] = r;
      if (r.length) { if (top < 0) top = y; bot = y; }
    }
    return { on, runs, top, bot, SH };
  }

  // Splits a body frame into head / torso / arms / legs from its silhouette.
  function segmentBody(a, angle) {
    const { runs, top, bot, SH } = a;
    const FH = bot - top + 1, AX = SW / 2;
    const lab = new Uint8Array(SW * SH);
    const rowW = y => runs[y].reduce((t, r) => t + r[1] - r[0] + 1, 0);
    const rowMid = y => { const r = runs[y]; return r.length ? (r[0][0] + r[r.length - 1][1]) / 2 : AX; };

    const rad = angle * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
    const profile = Math.abs(cos) < 0.42;
    // Viewer-left limb is the model's right when the model faces us.
    const vl = cos >= 0 ? "right" : "left", vr = vl === "right" ? "left" : "right";
    const near = sin >= 0 ? "right" : "left";

    // Neck: narrowest row near the top.
    let neck = top + Math.round(0.15 * FH), best = 1e9;
    for (let y = Math.round(top + 0.08 * FH); y < top + 0.2 * FH; y++) { const w = rowW(y); if (w && w < best) { best = w; neck = y; } }
    const shoulder = neck + Math.round(0.03 * FH);

    // Crotch: first row where a central gap opens between two leg-width runs and stays open.
    const legGap = (y, ref) => {
      const r = runs[y]; if (!r) return null;
      let bestG = null;
      for (let i = 0; i < r.length - 1; i++) {
        const gc = (r[i][1] + r[i + 1][0]) / 2;
        if (Math.abs(gc - ref) < 0.07 * FH && r[i][1] - r[i][0] > 0.03 * FH && r[i + 1][1] - r[i + 1][0] > 0.03 * FH) {
          if (bestG === null || Math.abs(gc - ref) < Math.abs(bestG - ref)) bestG = gc;
        }
      }
      return bestG;
    };
    let crotch = -1, split = AX;
    if (!profile) {
      for (let y = Math.round(top + 0.45 * FH); y < top + 0.7 * FH; y++) {
        const g = legGap(y, AX); if (g === null) continue;
        let ok = true; for (let k = 1; k <= 6; k++) if (legGap(y + k, AX) === null) { ok = false; break; }
        if (ok) { crotch = y; split = g; break; }
      }
    }
    const legsSplit = crotch > 0;
    if (!legsSplit) crotch = Math.round(top + 0.565 * FH);
    const legCut = crotch - Math.round(0.02 * FH);

    const splitAt = new Float32Array(SH).fill(split);
    if (legsSplit) {
      let ref = split;
      for (let y = crotch; y <= bot; y++) { const g = legGap(y, ref); if (g !== null) ref = g; splitAt[y] = ref; }
    }

    for (let y = top; y <= bot; y++) {
      for (const [s, e] of runs[y]) {
        for (let x = s; x <= e; x++) {
          let v;
          if (y <= neck) v = L.head;
          else if (y >= legCut) v = legsSplit ? (x < splitAt[y] ? L[vl + "Leg"] : L[vr + "Leg"]) : L.legs;
          else v = L.torso;
          lab[y * SW + x] = v;
        }
      }
    }

    // Arms: find the armpit where an outer run separates from the torso.
    const armSep = (y, side) => {
      const r = runs[y]; if (!r || r.length < 2) return null;
      const o = side < 0 ? r[0] : r[r.length - 1], n = side < 0 ? r[1] : r[r.length - 2];
      if (o[1] - o[0] + 1 > 0.1 * FH) return null;
      if (side < 0 ? o[1] >= AX - 0.04 * FH : o[0] <= AX + 0.04 * FH) return null;
      return side < 0 ? (o[1] + n[0]) / 2 : (n[1] + o[0]) / 2;
    };
    const findArm = side => {
      for (let y = shoulder + Math.round(0.06 * FH); y < top + 0.5 * FH; y++) {
        const s = armSep(y, side); if (s === null) continue;
        let ok = true; for (let k = 1; k <= 8; k++) if (armSep(y + k, side) === null) { ok = false; break; }
        if (ok) return { y, inner: s };
      }
      return null;
    };
    const paintArm = (arm, side, v) => {
      const xTop = arm.inner + (AX - arm.inner) * 0.12;
      for (let y = shoulder; y < arm.y; y++) {
        const t = (y - shoulder) / Math.max(1, arm.y - shoulder);
        const cut = xTop + (arm.inner - xTop) * t;
        for (const [s, e] of runs[y]) for (let x = s; x <= e; x++) if (side < 0 ? x < cut : x > cut) lab[y * SW + x] = v;
      }
      let miss = 0;
      for (let y = arm.y; y <= bot && y < crotch + 0.13 * FH && miss < 10; y++) {
        let hit = false;
        for (const [s, e] of runs[y]) {
          if (side < 0 ? e <= arm.inner + 2 : s >= arm.inner - 2) { hit = true; for (let x = s; x <= e; x++) lab[y * SW + x] = v; }
        }
        miss = hit ? 0 : miss + 1;
      }
    };
    // Fallback when an arm overlaps the body: a band hanging from the shoulder.
    const bandArm = (where, v) => {
      const w = 0.045 * FH;
      for (let y = shoulder + Math.round(0.015 * FH); y < top + 0.55 * FH; y++) {
        const r = runs[y]; if (!r.length) continue;
        let c;
        if (where === "mid") c = rowMid(y) + 0.01 * FH;
        else if (where < 0) c = r[0][0] + w;
        else c = r[r.length - 1][1] - w;
        for (const [s, e] of r) for (let x = Math.max(s, Math.round(c - w)); x <= Math.min(e, Math.round(c + w)); x++) lab[y * SW + x] = v;
      }
    };

    if (profile) {
      bandArm("mid", L[near + "Arm"]);
    } else {
      const left = findArm(-1), right = findArm(1);
      if (left) paintArm(left, -1, L[vl + "Arm"]); else bandArm(-1, L[vl + "Arm"]);
      if (right) paintArm(right, 1, L[vr + "Arm"]); else bandArm(1, L[vr + "Arm"]);
    }
    // Head stays on top of anything above the neck.
    for (let y = top; y <= neck; y++) for (const [s, e] of runs[y]) for (let x = s; x <= e; x++) lab[y * SW + x] = L.head;

    return { lab, SH, near };
  }

  // Head-view cues for conditions that are not tied to a limb.
  function segmentHead(a, angle, cond) {
    const { on, top, SH } = a;
    const lab = new Uint8Array(SW * SH);
    if (!cond || cond === "sleep") return { lab, SH };
    const rad = angle * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
    const HH = SH * 0.6 - top; // crown to chin
    const ears = [];
    const ex = (s) => 0.5 * SW + s * (0.29 * cos + 0.08 * sin) * SW; // s = -1 right ear, +1 left ear
    if (sin > -0.6) ears.push(ex(-1));
    if (sin < 0.6) ears.push(ex(1));
    for (let y = 0; y < SH; y++) {
      for (let x = 0; x < SW; x++) {
        if (!on[y * SW + x]) continue;
        const ry = (y - top) / HH;
        let hit = false;
        if (cond === "mentalHealth") hit = ry < 0.5;
        else if (cond === "migraine") hit = ry > 0.18 && ry < 0.5;
        else if (cond === "hearing") hit = ears.some(cx => ((x - cx) / (0.075 * SW)) ** 2 + ((y - (top + 0.66 * HH)) / (0.1 * SH)) ** 2 < 1);
        if (hit) lab[y * SW + x] = 1;
      }
    }
    return { lab, SH };
  }

  // ---------------------------------------------------------------- painting
  const scratch = document.createElement("canvas");
  const sctx = scratch.getContext("2d");
  let segOK = true;

  function partMatches(v, id) {
    if (!v) return false;
    if (v === L.legs) return id === "rightLeg" || id === "leftLeg";
    return v === L[id];
  }

  function currentEntry() { return cache.get(nearest(frames(), state.angle).src); }

  function ensureSeg(entry, frame) {
    const key = state.mode === "head" ? `head:${state.active?.id}` : "body";
    if (entry.seg && entry.segKey === key) return entry.seg;
    if (!entry.alpha) entry.alpha = readAlpha(entry.img);
    entry.seg = state.mode === "head" ? segmentHead(entry.alpha, frame.a, state.active?.id) : segmentBody(entry.alpha, frame.a);
    entry.segKey = key;
    return entry.seg;
  }

  function render() {
    const frame = nearest(frames(), state.angle);
    const entry = cache.get(frame.src);
    if (!entry || !entry.img.complete || !entry.img.naturalWidth) return;
    if (el.img.getAttribute("src") !== frame.src) el.img.src = frame.src;
    el.img.alt = `Veteran model, ${viewName(state.angle).toLowerCase()} view`;
    el.view.textContent = viewName(state.angle);
    el.angle.textContent = `${Math.round(state.angle)}°`;

    const W = entry.img.naturalWidth, H = entry.img.naturalHeight;
    if (el.paint.width !== W || el.paint.height !== H) { el.paint.width = W; el.paint.height = H; }
    pctx.clearRect(0, 0, W, H);
    if (!segOK) return updateMark(null);

    let seg;
    try { seg = ensureSeg(entry, frame); } catch (e) { segOK = false; console.warn("Part highlighting needs the page served over http(s).", e); return updateMark(null); }
    const { lab, SH } = seg;

    const act = state.active;
    const actPart = state.mode === "body" && act?.type === "part" ? act.id : null;
    const actHead = state.mode === "head";
    const added = new Set(state.conds.filter(c => c.type === "part").map(c => c.id));
    const hov = state.hover;

    if (scratch.width !== SW || scratch.height !== SH) { scratch.width = SW; scratch.height = SH; }
    const out = sctx.createImageData(SW, SH);
    const px = out.data;
    let minX = SW, minY = SH, maxX = -1, maxY = -1, sx = 0, sy = 0, n = 0;
    const isAct = v => (actHead ? v === 1 : actPart && partMatches(v, actPart));
    for (let y = 0; y < SH; y++) {
      for (let x = 0; x < SW; x++) {
        const i = y * SW + x, v = lab[i];
        if (!v) continue;
        let r = 0, g = 0, b = 0, a = 0;
        if (isAct(v)) {
          const edge = !isAct(lab[i - 1]) || !isAct(lab[i + 1]) || !isAct(lab[i - SW]) || !isAct(lab[i + SW]);
          if (edge) { r = 255; g = 255; b = 255; a = 230; } else { r = 191; g = 10; b = 48; a = 150; }
          if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; sx += x; sy += y; n++;
        } else if (state.mode === "body" && [...added].some(id => partMatches(v, id))) {
          r = 191; g = 10; b = 48; a = 80;
        } else if (hov && state.mode === "body" && partMatches(v, hov)) {
          r = 255; g = 255; b = 255; a = 60;
        }
        const o = i * 4; px[o] = r; px[o + 1] = g; px[o + 2] = b; px[o + 3] = a;
      }
    }
    sctx.putImageData(out, 0, 0);
    pctx.imageSmoothingEnabled = true;
    pctx.drawImage(scratch, 0, 0, W, H);
    pctx.globalCompositeOperation = "destination-in";
    pctx.drawImage(entry.img, 0, 0, W, H); // clip the overlay to the exact silhouette
    pctx.globalCompositeOperation = "source-over";

    updateMark(n > 40 ? { minX: minX / SW, maxX: maxX / SW, minY: minY / SH, maxY: maxY / SH, cx: sx / n / SW, cy: sy / n / SH } : null);
  }

  // Brackets, crosshair and the "Marked" tag follow the selected region.
  function updateMark(box) {
    const act = state.active;
    const name = !act ? "—" : act.type === "part" ? PART_NAMES[act.id] : COND_NAMES[act.id];
    const imgTop = state.mode === "head" ? 0.06 : 0, imgH = state.mode === "head" ? 1000 / 1424 : 1;
    root.classList.toggle("has-mark", !!act);
    if (!act) return;
    if (!box) {
      el.tagLabel.textContent = act.type === "part" && state.mode === "body" ? `${name} · turn to see` : name;
      root.style.setProperty("--bw", "0px");
      root.style.setProperty("--cx", "-999%");
      root.style.setProperty("--cy", "-999%");
      setTag(0.62, 0.08, false);
      return;
    }
    el.tagLabel.textContent = name;
    const pad = 0.025;
    const bx = box.minX - pad, by = imgTop + (box.minY - pad) * imgH, bw = box.maxX - box.minX + pad * 2, bh = (box.maxY - box.minY + pad * 2) * imgH;
    root.style.setProperty("--bx", `${bx * 100}%`);
    root.style.setProperty("--by", `${by * 100}%`);
    root.style.setProperty("--bw", `${bw * 100}%`);
    root.style.setProperty("--bh", `${bh * 100}%`);
    root.style.setProperty("--cx", `${box.cx * 100}%`);
    root.style.setProperty("--cy", `${(imgTop + box.cy * imgH) * 100}%`);
    const right = bx + bw;
    if (right < 0.74) setTag(right + 0.02, by, false); else setTag(bx - 0.02, by, true);
  }
  function setTag(x, y, left) {
    root.style.setProperty("--tx", `${x * 100}%`);
    root.style.setProperty("--ty", `${Math.max(0, y) * 100}%`);
    el.tag.classList.toggle("is-left", left);
  }

  function viewName(a) {
    const c = [[0, "Front"], [90, "Right side"], [180, "Back"], [270, "Left side"], [360, "Front"]];
    const n = c.reduce((b, x) => (Math.abs(x[0] - a) < Math.abs(b[0] - a) ? x : b));
    if (Math.abs(n[0] - a) <= 12) return n[1];
    return a < 90 ? "Front right" : a < 180 ? "Back right" : a < 270 ? "Back left" : "Front left";
  }

  // ---------------------------------------------------------------- interaction
  function setAngle(a) {
    state.angle = norm(a);
    const f = nearest(frames(), state.angle);
    loadFrame(f.src).then(() => render());
  }

  function hitTest(ev) {
    const entry = currentEntry();
    if (!entry || !entry.seg || state.mode !== "body") return null;
    const r = el.img.getBoundingClientRect();
    const x = Math.floor((ev.clientX - r.left) / r.width * SW);
    const y = Math.floor((ev.clientY - r.top) / r.height * entry.seg.SH);
    if (x < 0 || y < 0 || x >= SW || y >= entry.seg.SH) return null;
    const v = entry.seg.lab[y * SW + x];
    if (!v) return null;
    if (v === L.legs) return entry.seg.near + "Leg";
    return Object.keys(L).find(k => L[k] === v) || null;
  }

  root.addEventListener("pointerdown", ev => {
    if (ev.button !== undefined && ev.button !== 0) return;
    state.drag = { x: ev.clientX, a: state.angle, moved: false, id: ev.pointerId };
  });
  root.addEventListener("pointermove", ev => {
    const d = state.drag;
    if (d) {
      const dx = ev.clientX - d.x;
      if (!d.moved && Math.abs(dx) > 6) { d.moved = true; root.classList.add("is-dragging"); root.setPointerCapture?.(d.id); }
      if (d.moved) { setAngle(d.a - dx * 0.45); return; }
    }
    if (ev.pointerType === "mouse") {
      const part = hitTest(ev);
      root.classList.toggle("is-hovering", !!part);
      if (part !== state.hover) { state.hover = part; render(); }
    }
  });
  const endDrag = ev => {
    const d = state.drag; state.drag = null;
    root.classList.remove("is-dragging");
    if (!d) return;
    try { root.releasePointerCapture?.(d.id); } catch (_) { /* not captured */ }
    if (!d.moved && ev.type === "pointerup") {
      const part = hitTest(ev);
      if (part) select({ type: "part", id: part });
    }
  };
  root.addEventListener("pointerup", endDrag);
  root.addEventListener("pointercancel", endDrag);
  root.addEventListener("pointerleave", () => { if (state.hover) { state.hover = null; root.classList.remove("is-hovering"); render(); } });
  root.addEventListener("keydown", ev => {
    if (ev.key === "ArrowLeft") { ev.preventDefault(); setAngle(state.angle - 22.5); }
    else if (ev.key === "ArrowRight") { ev.preventDefault(); setAngle(state.angle + 22.5); }
    else if (ev.key === "Home") { ev.preventDefault(); setAngle(0); }
  });
  document.querySelectorAll("[data-turn]").forEach(b => b.addEventListener("click", () => setAngle(state.angle + Number(b.dataset.turn) * 22.5)));

  function select(sel) {
    state.active = sel;
    const mode = sel.type === "cond" && HEAD_CONDS.has(sel.id) ? "head" : "body";
    if (mode !== state.mode) {
      state.mode = mode;
      root.dataset.mode = mode;
      if (mode === "head") HEAD.forEach(f => loadFrame(f.src));
    }
    cache.forEach(e => { if (e.segKey && e.segKey !== "body") e.seg = null; });
    syncPicks();
    setAngle(state.angle);
  }

  function syncPicks() {
    document.querySelectorAll(".pick__btn").forEach(b => {
      const sel = b.dataset.part ? { type: "part", id: b.dataset.part } : { type: "cond", id: b.dataset.cond };
      const on = !!state.active && state.active.type === sel.type && state.active.id === sel.id;
      b.setAttribute("aria-pressed", String(on));
      b.classList.toggle("is-added", state.conds.some(c => c.type === sel.type && c.id === sel.id));
    });
  }
  document.querySelectorAll(".pick__btn").forEach(b => b.addEventListener("click", () => {
    select(b.dataset.part ? { type: "part", id: b.dataset.part } : { type: "cond", id: b.dataset.cond });
  }));

  // Effect chips
  const chips = [...document.querySelectorAll(".chip")];
  chips.forEach(c => c.addEventListener("click", () => {
    state.effect = c.dataset.effect;
    chips.forEach(o => o.setAttribute("aria-pressed", String(o === c)));
  }));

  // Severity meter (10 segments, single choice)
  const segs = [];
  for (let i = 1; i <= 10; i++) {
    const s = document.createElement("button");
    s.type = "button"; s.className = "sev__seg"; s.setAttribute("role", "radio");
    s.setAttribute("aria-label", `${i} of 10, ${SEV_TEXT(i)}`);
    s.addEventListener("click", () => setSeverity(i));
    s.addEventListener("keydown", ev => {
      if (ev.key === "ArrowRight" || ev.key === "ArrowUp") { ev.preventDefault(); setSeverity(Math.min(10, state.severity + 1), true); }
      if (ev.key === "ArrowLeft" || ev.key === "ArrowDown") { ev.preventDefault(); setSeverity(Math.max(1, state.severity - 1), true); }
    });
    el.meter.append(s); segs.push(s);
  }
  function setSeverity(v, focus) {
    state.severity = v;
    segs.forEach((s, i) => { s.classList.toggle("is-on", i < v); s.setAttribute("aria-checked", String(i + 1 === v)); s.tabIndex = i + 1 === v ? 0 : -1; });
    el.sevText.textContent = SEV_TEXT(v);
    if (focus) segs[v - 1].focus();
  }
  setSeverity(state.severity);

  // Conditions list
  el.add.addEventListener("click", () => {
    const a = state.active;
    if (!a) { el.live.textContent = "Mark a body part or a condition first."; return; }
    const name = a.type === "part" ? PART_NAMES[a.id] : COND_NAMES[a.id];
    const i = state.conds.findIndex(c => c.type === a.type && c.id === a.id);
    const entry = { ...a, name, effect: state.effect, sev: SEV_TEXT(state.severity) };
    if (i >= 0) state.conds[i] = entry; else state.conds.push(entry);
    renderConds();
    el.live.textContent = `${name}, ${entry.sev.toLowerCase()}, added. ${state.conds.length} condition${state.conds.length > 1 ? "s" : ""}.`;
  });
  function renderConds() {
    el.list.replaceChildren(...state.conds.map((c, i) => {
      const li = document.createElement("li");
      const t = document.createElement("span");
      t.textContent = `${String(i + 1).padStart(2, "0")} ${c.name} · ${c.sev}`;
      t.title = c.effect;
      const x = document.createElement("button");
      x.type = "button"; x.textContent = "x"; x.setAttribute("aria-label", `Remove ${c.name}`);
      x.addEventListener("click", () => { state.conds.splice(i, 1); renderConds(); el.live.textContent = `${c.name} removed.`; el.add.focus(); });
      li.append(t, x);
      return li;
    }));
    el.title.textContent = `Your conditions (${state.conds.length})`;
    el.empty.hidden = state.conds.length > 0;
    syncPicks();
    render();
  }

  // Household
  const spouse = document.getElementById("spouse");
  spouse?.addEventListener("click", () => {
    const on = spouse.getAttribute("aria-pressed") !== "true";
    spouse.setAttribute("aria-pressed", String(on));
    spouse.textContent = on ? "[ On ]" : "[ Off ]";
  });
  document.querySelectorAll("[data-count]").forEach(b => b.addEventListener("click", () => {
    const out = document.getElementById(b.dataset.count);
    out.value = out.textContent = String(Math.max(0, Math.min(9, Number(out.textContent) + Number(b.dataset.step))));
  }));

  // ---------------------------------------------------------------- start
  syncPicks();
  loadFrame(BODY[0].src).then(render);
  const warm = () => BODY.forEach(f => loadFrame(f.src));
  if ("requestIdleCallback" in window) requestIdleCallback(warm, { timeout: 2500 }); else setTimeout(warm, 1200);
  window.addEventListener("resize", () => render(), { passive: true });

  // Segmentation of any body frame, for tuning: returns { lab, SH, width } with label ids from L.
  async function segmentationOf(index) {
    const f = BODY[index]; const entry = await loadFrame(f.src);
    if (!entry.alpha) entry.alpha = readAlpha(entry.img);
    return { ...segmentBody(entry.alpha, f.a), width: SW, angle: f.a };
  }

  window.vacCalculator = { setAngle, select, segmentationOf, labels: L, getState: () => JSON.parse(JSON.stringify({ ...state, drag: null })) };
})();
